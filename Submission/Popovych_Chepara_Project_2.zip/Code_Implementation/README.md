# Description

## Main
The file in this directory **project.sh** represents our implementation of the whole pathogen analysis pipeline for samples of the **Patient No. 14**.

The manual on how to run the shell script file can be found inside at the very beginning of the file. Briefly said, script allows to run stages of the pipeline avoiding some if there's a need for it. Also it can run from scratch running all stages consecutively. 

---

## Additional
Additionally, the file includes script to download all necessary resources for tools to run, it can be also turned on or off based on your preferences and needs.

The report stage is empty since all of the reports are saved in **Descriptions** directory, accessible from the root directory of the project.