# Variant Filtering

After annotation, all three variant types were filtered in two steps: first in the Ensembl VEP web tool, then further refined using `analysis.ipynb`.

---

## CNVs

No filters were applied in VEP. The full annotation was downloaded and then filtered in the notebook:

- Removed uninformative columns
- Kept only genes from the COSMIC Cancer Gene Census and a short list of well-known cancer genes
- Removed duplicate entries

---

## SVs

Filtered in VEP first:

- Consequence is not intergenic_variant
- Consequence is not intron_variant
- Biotype is protein_coding
- Consequence is feature_truncation
- Canonical is YES

Then in the notebook:

- Removed uninformative columns
- Kept only entries with a pathogenic ClinVar classification
- Removed duplicate entries

---

## SNVs

Filtered in VEP first:

- Impact is HIGH
- Biotype is protein_coding
- Consequence is not intergenic_variant
- Consequence is not intron_variant
- gnomADe AF <= 0.001
- gnomADg AF <= 0.001

Then in the notebook:

- Removed uninformative columns
- Removed duplicate entries