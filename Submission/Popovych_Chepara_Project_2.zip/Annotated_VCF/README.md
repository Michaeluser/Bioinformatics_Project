# Explanation

## Unfiltered files
The **unfiltered_*** files are the result of Web VEP filtering annotated variants with predefined filters. They are described in **Proejct_Analysis_Report.pdf** file located in the **Descriptions** directory of the project's root directory. 

---

## Filtered files
The **filtered_*** files are the result of **analysis.ipynb** pipeline of filtering methods, applied to each unfiltered version of the variant calling file. 
Filtered versions of the file are described in the **Project_Analysis_Report.pdf** as well.