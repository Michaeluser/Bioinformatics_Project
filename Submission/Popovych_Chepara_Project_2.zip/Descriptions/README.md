# Explanation

## Annotation
**annotation.info** file comprising all infromation about chosen annotated variants that was used in the **Project_Analysis_Report.docx** is one of the core source files produced during work on this project.

---

## Raw Data Quality Report
**Data_QC_Report.txt** describes changes in the files before and after trimming during Raw Quality Assesment phase of the project.

---

## Mark Duplicates Report
**Duplicates_Report.txt** is a general summarized report on duplicates found in both aligned BAM files together, applied in Post-Processing stage of the project.

---

## Post Alignment Quality Control Report
**Post_Alignment_QC_Report.txt** is a comprehensive report circumventing both tumrous and control samples alignment process.